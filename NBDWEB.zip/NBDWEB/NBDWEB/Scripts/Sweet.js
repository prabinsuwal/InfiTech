﻿function bigImg(x) {
    alert("Info");
}

function normalImg(x) {
    
}
