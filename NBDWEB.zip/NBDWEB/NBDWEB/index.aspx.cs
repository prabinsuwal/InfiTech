﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NBDWEB
{
    public partial class ind : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn_Submit_Click(object sender, EventArgs e)
        {

            if (this.txtUserName.Text == "admin" && txtPassword.Text == "admin")
            {
                this.title.Text = "Hi Admin";
                Response.Redirect("Bid.aspx");
            }
            else
            {
                this.title.Text = "Invalid Login!";
            }
        }
    }
}